// Script base
document.addEventListener("DOMContentLoaded", function () {
    console.log("JavaScript cargado correctamente");
});